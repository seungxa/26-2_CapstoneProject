// Written by scripts/practice-track/build-extension.mjs
export const CONFIG = {
  apiUrl: "https://team-api.duckdns.org",
  webUrl: "http://localhost:5173",
};
